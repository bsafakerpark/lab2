package java240lab2pac;

public class Home {
	private String firstName;
	private String lastName;
	private int squareFootage;
	private double dwelling;
	private double contents;
	private double liability;
	
public void enterPolicyInfo(String firstName, String lastName, int squareFootage, double dwelling, double contents, double liability) {
	this.firstName = firstName;
	this.lastName = lastName;
	this.squareFootage = squareFootage;
	this.dwelling = dwelling;
	this.contents = contents;
	this.liability = liability;
	}

public double computeCommission() {
	return (liability * 0.30) + ((dwelling + contents) * 0.20);
	   }

public void printPolicy() {
	System.out.printf("Home Policy%n-----------%nName: %s %s%nFootage: %d%nDwelling: $%,.2f%nContents: $%,.2f%nLiability: $%,.2f%nCommission: $%,.2f%n%n",
			firstName, lastName, squareFootage, dwelling, contents, liability, computeCommission());
	    }
	}
